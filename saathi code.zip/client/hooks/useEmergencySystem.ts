import { useState, useEffect, useCallback, useRef } from 'react';

interface EmergencySettings {
  responseTimeoutMinutes: number;
  maxNonResponsiveChecks: number;
  checkIntervalMinutes: number;
  emergencyContact?: string;
  autoTriggerEnabled: boolean;
}

interface EmergencyState {
  isEmergencyMode: boolean;
  lastUserActivity: Date | null;
  nonResponsiveCount: number;
  pendingMessages: number;
  isMonitoring: boolean;
}

interface UseEmergencySystemReturn {
  emergencyState: EmergencyState;
  emergencySettings: EmergencySettings;
  triggerEmergency: () => void;
  dismissEmergency: () => void;
  recordUserActivity: () => void;
  recordMessageSent: () => void;
  recordMessageReceived: () => void;
  updateSettings: (settings: Partial<EmergencySettings>) => void;
  startMonitoring: () => void;
  stopMonitoring: () => void;
}

const DEFAULT_SETTINGS: EmergencySettings = {
  responseTimeoutMinutes: 30, // 30 minutes without response
  maxNonResponsiveChecks: 2, // After 2 checks, trigger emergency
  checkIntervalMinutes: 15, // Check every 15 minutes
  autoTriggerEnabled: true,
};

const DEFAULT_STATE: EmergencyState = {
  isEmergencyMode: false,
  lastUserActivity: null,
  nonResponsiveCount: 0,
  pendingMessages: 0,
  isMonitoring: false,
};

export function useEmergencySystem(): UseEmergencySystemReturn {
  const [emergencyState, setEmergencyState] = useState<EmergencyState>(DEFAULT_STATE);
  const [emergencySettings, setEmergencySettings] = useState<EmergencySettings>(DEFAULT_SETTINGS);
  
  const monitoringInterval = useRef<NodeJS.Timeout | null>(null);
  const lastActivityRef = useRef<Date | null>(null);

  // Load settings from localStorage on mount
  useEffect(() => {
    const savedSettings = localStorage.getItem('saathi_emergency_settings');
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        setEmergencySettings(prev => ({ ...prev, ...parsed }));
      } catch (error) {
        console.error('Failed to load emergency settings:', error);
      }
    }

    const savedEmergencyContact = localStorage.getItem('saathi_emergency_contact');
    if (savedEmergencyContact) {
      setEmergencySettings(prev => ({ ...prev, emergencyContact: savedEmergencyContact }));
    }
  }, []);

  // Save settings to localStorage when changed
  useEffect(() => {
    localStorage.setItem('saathi_emergency_settings', JSON.stringify(emergencySettings));
    if (emergencySettings.emergencyContact) {
      localStorage.setItem('saathi_emergency_contact', emergencySettings.emergencyContact);
    }
  }, [emergencySettings]);

  // Update lastActivityRef when state changes
  useEffect(() => {
    lastActivityRef.current = emergencyState.lastUserActivity;
  }, [emergencyState.lastUserActivity]);

  const recordUserActivity = useCallback(() => {
    const now = new Date();
    setEmergencyState(prev => ({
      ...prev,
      lastUserActivity: now,
      nonResponsiveCount: 0, // Reset counter on activity
      pendingMessages: 0, // Clear pending messages
    }));
    
    // If emergency mode was active, dismiss it on user activity
    if (emergencyState.isEmergencyMode) {
      setEmergencyState(prev => ({
        ...prev,
        isEmergencyMode: false,
      }));
    }
  }, [emergencyState.isEmergencyMode]);

  const recordMessageSent = useCallback(() => {
    setEmergencyState(prev => ({
      ...prev,
      pendingMessages: prev.pendingMessages + 1,
    }));
  }, []);

  const recordMessageReceived = useCallback(() => {
    recordUserActivity(); // Receiving messages counts as activity
  }, [recordUserActivity]);

  const triggerEmergency = useCallback(() => {
    setEmergencyState(prev => ({
      ...prev,
      isEmergencyMode: true,
    }));

    // Notify emergency contact if available
    if (emergencySettings.emergencyContact) {
      // In a real implementation, this would send notifications
      console.log('Emergency triggered - notifying emergency contact:', emergencySettings.emergencyContact);
    }

    // Track emergency events for analytics/support
    console.log('Emergency mode activated:', {
      timestamp: new Date(),
      lastActivity: lastActivityRef.current,
      nonResponsiveCount: emergencyState.nonResponsiveCount,
      pendingMessages: emergencyState.pendingMessages,
    });
  }, [emergencySettings.emergencyContact, emergencyState.nonResponsiveCount, emergencyState.pendingMessages]);

  const dismissEmergency = useCallback(() => {
    setEmergencyState(prev => ({
      ...prev,
      isEmergencyMode: false,
      nonResponsiveCount: 0,
      pendingMessages: 0,
    }));
  }, []);

  const updateSettings = useCallback((newSettings: Partial<EmergencySettings>) => {
    setEmergencySettings(prev => ({ ...prev, ...newSettings }));
  }, []);

  const checkUserResponsiveness = useCallback(() => {
    const now = new Date();
    const lastActivity = lastActivityRef.current;

    if (!lastActivity) {
      return; // No activity recorded yet
    }

    const timeSinceActivity = now.getTime() - lastActivity.getTime();
    const timeoutMs = emergencySettings.responseTimeoutMinutes * 60 * 1000;

    // Check if user has been non-responsive beyond timeout and has pending messages
    if (timeSinceActivity > timeoutMs && emergencyState.pendingMessages > 0) {
      setEmergencyState(prev => {
        const newCount = prev.nonResponsiveCount + 1;
        
        // Trigger emergency if we've reached the threshold
        if (newCount >= emergencySettings.maxNonResponsiveChecks && emergencySettings.autoTriggerEnabled) {
          setTimeout(triggerEmergency, 0); // Trigger on next tick
        }

        return {
          ...prev,
          nonResponsiveCount: newCount,
        };
      });
    }
  }, [
    emergencySettings.responseTimeoutMinutes,
    emergencySettings.maxNonResponsiveChecks,
    emergencySettings.autoTriggerEnabled,
    emergencyState.pendingMessages,
    triggerEmergency
  ]);

  const startMonitoring = useCallback(() => {
    if (!emergencySettings.autoTriggerEnabled) return;

    setEmergencyState(prev => ({ ...prev, isMonitoring: true }));
    
    // Clear existing interval
    if (monitoringInterval.current) {
      clearInterval(monitoringInterval.current);
    }

    // Start monitoring interval
    monitoringInterval.current = setInterval(
      checkUserResponsiveness,
      emergencySettings.checkIntervalMinutes * 60 * 1000
    );

    console.log('Emergency monitoring started');
  }, [emergencySettings.autoTriggerEnabled, emergencySettings.checkIntervalMinutes, checkUserResponsiveness]);

  const stopMonitoring = useCallback(() => {
    setEmergencyState(prev => ({ ...prev, isMonitoring: false }));
    
    if (monitoringInterval.current) {
      clearInterval(monitoringInterval.current);
      monitoringInterval.current = null;
    }

    console.log('Emergency monitoring stopped');
  }, []);

  // Cleanup interval on unmount
  useEffect(() => {
    return () => {
      if (monitoringInterval.current) {
        clearInterval(monitoringInterval.current);
      }
    };
  }, []);

  // Auto-start monitoring when settings enable it
  useEffect(() => {
    if (emergencySettings.autoTriggerEnabled && !emergencyState.isMonitoring) {
      startMonitoring();
    } else if (!emergencySettings.autoTriggerEnabled && emergencyState.isMonitoring) {
      stopMonitoring();
    }
  }, [emergencySettings.autoTriggerEnabled, emergencyState.isMonitoring, startMonitoring, stopMonitoring]);

  return {
    emergencyState,
    emergencySettings,
    triggerEmergency,
    dismissEmergency,
    recordUserActivity,
    recordMessageSent,
    recordMessageReceived,
    updateSettings,
    startMonitoring,
    stopMonitoring,
  };
}
