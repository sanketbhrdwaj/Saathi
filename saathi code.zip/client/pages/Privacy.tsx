import PlaceholderPage from "./PlaceholderPage";

export default function Privacy() {
  return (
    <PlaceholderPage
      title="Privacy Policy"
      description="Learn how we protect your personal information and maintain your privacy on the Saathi platform."
    />
  );
}
