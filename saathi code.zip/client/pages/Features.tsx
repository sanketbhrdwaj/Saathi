import PlaceholderPage from "./PlaceholderPage";

export default function Features() {
  return (
    <PlaceholderPage
      title="Features"
      description="Discover all the powerful features that make Saathi your ideal mental health companion."
    />
  );
}
