import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import Layout from "@/components/Layout";
import EmergencyButton from "@/components/EmergencyButton";
import EmergencyModal from "@/components/EmergencyModal";
import { useEmergencySystem } from "@/hooks/useEmergencySystem";
import { motion, AnimatePresence } from "framer-motion";
import { Send, MessageCircle, Heart } from "lucide-react";

interface Message {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: Date;
}

const initialMessages: Message[] = [
  {
    id: "1",
    content: "Hello! I'm Saathi, your personal mental health companion. I'm here to listen, support, and help you navigate through whatever you're feeling right now. How are you doing today?",
    isUser: false,
    timestamp: new Date(),
  }
];

const sampleResponses = [
  "I hear you, and what you're feeling is completely valid. It takes courage to share these thoughts. Can you tell me more about what's been weighing on your mind lately?",
  "Thank you for trusting me with this. Remember, you're not alone in feeling this way. Many people experience similar emotions, and it's okay to not be okay sometimes. What has helped you feel even a little bit better in the past?",
  "I appreciate you opening up about this. Your feelings matter, and so do you. When you're feeling overwhelmed, sometimes it helps to focus on just the next small step. What's one tiny thing you could do right now to take care of yourself?",
  "That sounds really challenging, and I want you to know that I'm here with you through this. You've been so strong by reaching out and sharing. Have you been able to talk to anyone else about how you're feeling?",
  "I can sense the pain in your words, and I want you to know that your feelings are heard and acknowledged. Sometimes when we're in a dark place, it's hard to see any light, but you took a brave step by coming here today. What brought you to reach out for support right now?"
];

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Emergency system integration
  const {
    emergencyState,
    emergencySettings,
    triggerEmergency,
    dismissEmergency,
    recordUserActivity,
    recordMessageSent,
    recordMessageReceived,
    startMonitoring
  } = useEmergencySystem();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  // Start emergency monitoring when chat loads
  useEffect(() => {
    startMonitoring();
    recordUserActivity(); // Record initial activity
  }, [startMonitoring, recordUserActivity]);

  // Record activity on various user interactions
  useEffect(() => {
    const handleUserInteraction = () => {
      recordUserActivity();
    };

    // Listen for various user interactions
    window.addEventListener('click', handleUserInteraction);
    window.addEventListener('keydown', handleUserInteraction);
    window.addEventListener('scroll', handleUserInteraction);
    window.addEventListener('mousemove', handleUserInteraction);

    return () => {
      window.removeEventListener('click', handleUserInteraction);
      window.removeEventListener('keydown', handleUserInteraction);
      window.removeEventListener('scroll', handleUserInteraction);
      window.removeEventListener('mousemove', handleUserInteraction);
    };
  }, [recordUserActivity]);

  const sendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString() + "-user",
      content: inputValue.trim(),
      isUser: true,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsTyping(true);

    // Record user activity and message received
    recordUserActivity();
    recordMessageReceived();

    // Simulate AI response delay
    setTimeout(() => {
      const randomResponse = sampleResponses[Math.floor(Math.random() * sampleResponses.length)];
      const botMessage: Message = {
        id: Date.now().toString() + "-bot",
        content: randomResponse,
        isUser: false,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);

      // Record message sent by Saathi
      recordMessageSent();
    }, 1500 + Math.random() * 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleEmergencyClick = () => {
    setShowEmergencyModal(true);
  };

  const handleEmergencyDismiss = () => {
    dismissEmergency();
  };

  return (
    <Layout>
      <div className="min-h-[calc(100vh-4rem)] flex">
        {/* Chat Container */}
        <div className="flex-1 flex flex-col max-w-4xl mx-auto">
          {/* Header */}
          <motion.div
            className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-16 z-10"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="p-4">
              <div className="flex items-center gap-3">
                <motion.div
                  className="w-10 h-10 rounded-lg bg-white/10 backdrop-blur-sm flex items-center justify-center p-1"
                  animate={{
                    scale: [1, 1.05, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  <img
                    src="https://cdn.builder.io/api/v1/image/assets%2F48dfbab388fe421facbbe9bc06be32cd%2Ff355c7465c23428f97de17feeb75558e?format=webp&width=800"
                    alt="Saathi Logo"
                    className="w-full h-full object-contain"
                  />
                </motion.div>
                <div>
                  <h1 className="text-xl font-semibold">Saathi</h1>
                  <p className="text-sm text-muted-foreground">Your mental health companion</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            <AnimatePresence>
              {messages.map((message, index) => (
                <motion.div
                  key={message.id}
                  className={`flex ${message.isUser ? "justify-end" : "justify-start"}`}
                  initial={{ opacity: 0, y: 20, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -20, scale: 0.95 }}
                  transition={{
                    duration: 0.3,
                    delay: index * 0.1,
                    type: "spring",
                    stiffness: 300
                  }}
                >
                  <motion.div
                    className={`max-w-[80%] ${
                      message.isUser
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted"
                    } rounded-lg p-4 shadow-sm`}
                    whileHover={{ scale: 1.02 }}
                    transition={{ type: "spring", stiffness: 400 }}
                  >
                    {!message.isUser && (
                      <motion.div
                        className="flex items-center gap-2 mb-2"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.2 }}
                      >
                        <motion.div
                          animate={{ scale: [1, 1.2, 1] }}
                          transition={{ duration: 1.5, repeat: Infinity }}
                        >
                          <Heart className="w-4 h-4 text-brand-mint" />
                        </motion.div>
                        <span className="text-sm font-medium text-brand-green">Saathi</span>
                      </motion.div>
                    )}
                    <motion.p
                      className="text-sm leading-relaxed"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.3 }}
                    >
                      {message.content}
                    </motion.p>
                    <motion.p
                      className="text-xs opacity-70 mt-2"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.4 }}
                    >
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </motion.p>
                  </motion.div>
                </motion.div>
              ))}
            </AnimatePresence>

            <AnimatePresence>
              {isTyping && (
                <motion.div
                  className="flex justify-start"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <motion.div
                    className="max-w-[80%] bg-muted rounded-lg p-4 shadow-sm"
                    initial={{ scale: 0.9 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <motion.div
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                      >
                        <Heart className="w-4 h-4 text-brand-teal" />
                      </motion.div>
                      <span className="text-sm font-medium text-brand-blue">Saathi</span>
                    </div>
                    <div className="flex space-x-1">
                      <motion.div
                        className="w-2 h-2 bg-muted-foreground rounded-full"
                        animate={{ y: [0, -8, 0] }}
                        transition={{ duration: 0.6, repeat: Infinity }}
                      />
                      <motion.div
                        className="w-2 h-2 bg-muted-foreground rounded-full"
                        animate={{ y: [0, -8, 0] }}
                        transition={{ duration: 0.6, repeat: Infinity, delay: 0.1 }}
                      />
                      <motion.div
                        className="w-2 h-2 bg-muted-foreground rounded-full"
                        animate={{ y: [0, -8, 0] }}
                        transition={{ duration: 0.6, repeat: Infinity, delay: 0.2 }}
                      />
                    </div>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <motion.div
            className="border-t bg-background p-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="flex gap-2">
              <motion.div className="flex-1">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Share what's on your mind... I'm here to listen."
                  className="flex-1"
                  disabled={isTyping}
                />
              </motion.div>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  onClick={sendMessage}
                  disabled={!inputValue.trim() || isTyping}
                  className="gradient-saathi text-white"
                >
                  <motion.div
                    animate={{ rotate: isTyping ? 360 : 0 }}
                    transition={{ duration: 1, repeat: isTyping ? Infinity : 0 }}
                  >
                    <Send className="w-4 h-4" />
                  </motion.div>
                </Button>
              </motion.div>
            </div>
            <motion.p
              className="text-xs text-muted-foreground mt-2 text-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              Your conversations are private and secure. Saathi is here to support you.
            </motion.p>
          </motion.div>
        </div>

        {/* Sidebar - Support Resources */}
        <motion.div
          className="hidden lg:block w-80 border-l bg-muted/30 p-6"
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <motion.h3
            className="font-semibold mb-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            Need immediate help?
          </motion.h3>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card className="mb-4">
              <CardContent className="p-4">
                <h4 className="font-medium mb-2">Crisis Support</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  If you're having thoughts of self-harm, please reach out immediately:
                </p>
                <div className="space-y-1 text-sm">
                  <p><strong>Emergency:</strong> 911</p>
                  <p><strong>Crisis Hotline:</strong> 988</p>
                  <p><strong>Text Crisis Line:</strong> Text HOME to 741741</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
          >
            <Card className="mb-4">
              <CardContent className="p-4">
                <h4 className="font-medium mb-2">Expert Help</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Connect with licensed therapists for deeper support.
                </p>
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button variant="outline" size="sm" className="w-full">
                    Find a Therapist
                  </Button>
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
          >
            <Card>
              <CardContent className="p-4">
                <h4 className="font-medium mb-2">Self-Care Tips</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Take deep breaths</li>
                  <li>• Go for a short walk</li>
                  <li>• Call a trusted friend</li>
                  <li>• Practice gratitude</li>
                  <li>• Listen to calming music</li>
                </ul>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      </div>

      {/* Emergency Button */}
      <EmergencyButton
        isEmergencyMode={emergencyState.isEmergencyMode}
        onEmergencyClick={handleEmergencyClick}
        onDismiss={handleEmergencyDismiss}
      />

      {/* Emergency Modal */}
      <EmergencyModal
        isOpen={showEmergencyModal}
        onClose={() => setShowEmergencyModal(false)}
        emergencyContact={emergencySettings.emergencyContact}
      />
    </Layout>
  );
}
