import PlaceholderPage from "./PlaceholderPage";

export default function Login() {
  return (
    <PlaceholderPage
      title="Sign In"
      description="Sign in to your existing Saathi account to continue your mental health journey."
    />
  );
}
