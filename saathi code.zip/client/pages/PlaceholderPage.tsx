import Layout from "@/components/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Construction, MessageCircle } from "lucide-react";

interface PlaceholderPageProps {
  title: string;
  description: string;
}

export default function PlaceholderPage({ title, description }: PlaceholderPageProps) {
  return (
    <Layout>
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-6 rounded-full gradient-saathi flex items-center justify-center">
              <Construction className="w-8 h-8 text-white" />
            </div>
            
            <h1 className="text-2xl font-bold mb-4">{title}</h1>
            <p className="text-muted-foreground mb-6">
              {description} This page is coming soon. In the meantime, you can start chatting with Saathi.
            </p>
            
            <Button className="gradient-saathi text-white" asChild>
              <Link to="/chat">
                <MessageCircle className="w-4 h-4 mr-2" />
                Start Chatting
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
