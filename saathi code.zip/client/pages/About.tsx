import PlaceholderPage from "./PlaceholderPage";

export default function About() {
  return (
    <PlaceholderPage
      title="About Saathi"
      description="Learn more about our mission to provide compassionate mental health support to everyone who needs it."
    />
  );
}
