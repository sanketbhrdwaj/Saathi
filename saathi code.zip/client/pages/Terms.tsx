import PlaceholderPage from "./PlaceholderPage";

export default function Terms() {
  return (
    <PlaceholderPage
      title="Terms of Service"
      description="Review our terms of service and user agreement for the Saathi platform."
    />
  );
}
