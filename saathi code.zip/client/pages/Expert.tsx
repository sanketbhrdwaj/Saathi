import PlaceholderPage from "./PlaceholderPage";

export default function Expert() {
  return (
    <PlaceholderPage
      title="Expert Support"
      description="Connect with licensed therapists and mental health professionals for personalized care."
    />
  );
}
