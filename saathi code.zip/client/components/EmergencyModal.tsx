import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Phone, 
  MessageSquare, 
  MapPin, 
  Clock, 
  Heart, 
  Shield,
  ExternalLink,
  X,
  AlertTriangle,
  Users
} from "lucide-react";

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  emergencyContact?: string;
}

interface CrisisResource {
  name: string;
  phone: string;
  text?: string;
  website?: string;
  description: string;
  available: string;
  icon: React.ReactNode;
  urgent?: boolean;
}

const crisisResources: CrisisResource[] = [
  {
    name: "National Suicide Prevention Lifeline",
    phone: "988",
    description: "Free and confidential emotional support 24/7",
    available: "24/7",
    icon: <Phone className="w-5 h-5" />,
    urgent: true
  },
  {
    name: "Crisis Text Line",
    phone: "Text HOME to 741741",
    text: "741741",
    description: "Crisis counseling via text message",
    available: "24/7",
    icon: <MessageSquare className="w-5 h-5" />,
    urgent: true
  },
  {
    name: "Emergency Services",
    phone: "911",
    description: "Immediate emergency medical assistance",
    available: "24/7",
    icon: <AlertTriangle className="w-5 h-5" />,
    urgent: true
  },
  {
    name: "SAMHSA National Helpline",
    phone: "1-800-662-4357",
    description: "Treatment referral and information service",
    available: "24/7",
    icon: <Users className="w-5 h-5" />
  },
  {
    name: "LGBT National Hotline",
    phone: "1-888-843-4564",
    description: "Support for LGBTQ+ individuals in crisis",
    available: "Mon-Fri 4PM-12AM, Sat 12PM-5PM EST",
    icon: <Heart className="w-5 h-5" />
  }
];

const immediateSteps = [
  "Take slow, deep breaths",
  "Find a safe, comfortable space",
  "Reach out to someone you trust",
  "Consider calling a crisis hotline",
  "Remove harmful objects from your area",
  "Stay with others if possible"
];

export default function EmergencyModal({ isOpen, onClose, emergencyContact }: EmergencyModalProps) {
  const [selectedResource, setSelectedResource] = useState<CrisisResource | null>(null);

  const handleCall = (phone: string) => {
    // Remove any non-numeric characters for the tel: link
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    window.location.href = `tel:${cleanPhone}`;
  };

  const handleText = (text: string) => {
    window.location.href = `sms:${text}`;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
              className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center"
            >
              <Shield className="w-5 h-5 text-white" />
            </motion.div>
            Emergency Support Resources
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Immediate Safety Message */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-red-50 border border-red-200 rounded-lg p-4"
          >
            <div className="flex items-start gap-3">
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 0.5, repeat: Infinity }}
              >
                <AlertTriangle className="w-6 h-6 text-red-500 flex-shrink-0 mt-0.5" />
              </motion.div>
              <div>
                <h3 className="font-semibold text-red-800 mb-2">
                  If you're in immediate danger, call 911 right now
                </h3>
                <p className="text-red-700 text-sm">
                  Your safety is the most important thing. These resources are here to help you through this difficult time.
                </p>
              </div>
            </div>
          </motion.div>

          {/* Personal Emergency Contact */}
          {emergencyContact && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card className="border-blue-200 bg-blue-50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Heart className="w-5 h-5 text-blue-600" />
                    Your Emergency Contact
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <p className="font-medium text-blue-800">{emergencyContact}</p>
                    <Button
                      onClick={() => handleCall(emergencyContact)}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <Phone className="w-4 h-4 mr-2" />
                      Call Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Crisis Hotlines */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Phone className="w-6 h-6 text-brand-blue" />
              Crisis Support Hotlines
            </h3>
            
            <div className="grid gap-4">
              {crisisResources.map((resource, index) => (
                <motion.div
                  key={resource.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                >
                  <Card className={`hover:shadow-lg transition-shadow ${
                    resource.urgent ? 'border-red-200 bg-red-50' : 'border-gray-200'
                  }`}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3 flex-1">
                          <div className={`p-2 rounded-full ${
                            resource.urgent ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'
                          }`}>
                            {resource.icon}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold mb-1">{resource.name}</h4>
                            <p className="text-sm text-muted-foreground mb-2">
                              {resource.description}
                            </p>
                            <div className="flex items-center gap-4 text-sm">
                              <div className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                <span>{resource.available}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2 ml-4">
                          <Button
                            onClick={() => handleCall(resource.phone)}
                            className={resource.urgent ? 'bg-red-600 hover:bg-red-700' : 'bg-blue-600 hover:bg-blue-700'}
                            size="sm"
                          >
                            <Phone className="w-3 h-3 mr-1" />
                            Call
                          </Button>
                          {resource.text && (
                            <Button
                              onClick={() => handleText(resource.text)}
                              variant="outline"
                              size="sm"
                            >
                              <MessageSquare className="w-3 h-3 mr-1" />
                              Text
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Immediate Coping Steps */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Heart className="w-6 h-6 text-brand-teal" />
              Immediate Steps You Can Take
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {immediateSteps.map((step, index) => (
                <motion.div
                  key={step}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                  className="flex items-center gap-3 p-3 bg-green-50 border border-green-200 rounded-lg"
                >
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-white text-xs font-bold">{index + 1}</span>
                  </div>
                  <span className="text-green-800 font-medium">{step}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Reminder Message */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0 }}
            className="bg-brand-blue/10 border border-brand-blue/20 rounded-lg p-4 text-center"
          >
            <Heart className="w-8 h-8 text-brand-blue mx-auto mb-3" />
            <h3 className="font-semibold text-brand-blue mb-2">
              Remember: This feeling is temporary
            </h3>
            <p className="text-sm text-muted-foreground">
              You are not alone, and there are people who want to help. Your life has value, 
              and there are ways through this difficult time.
            </p>
          </motion.div>

          {/* Close Button */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2 }}
            className="flex justify-center pt-4"
          >
            <Button
              onClick={onClose}
              variant="outline"
              className="px-8"
            >
              I'm Safe Now
            </Button>
          </motion.div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
