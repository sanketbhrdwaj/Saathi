import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion } from "framer-motion";
import { Settings, Shield, Clock, Phone, Save, AlertTriangle } from "lucide-react";
import { useEmergencySystem } from "@/hooks/useEmergencySystem";

interface EmergencySettingsProps {
  trigger?: React.ReactNode;
}

export default function EmergencySettings({ trigger }: EmergencySettingsProps) {
  const { emergencyState, emergencySettings, updateSettings } = useEmergencySystem();
  const [isOpen, setIsOpen] = useState(false);
  const [localSettings, setLocalSettings] = useState(emergencySettings);

  const handleSettingChange = (key: keyof typeof emergencySettings, value: any) => {
    setLocalSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleSave = () => {
    updateSettings(localSettings);
    setIsOpen(false);
  };

  const handleCancel = () => {
    setLocalSettings(emergencySettings);
    setIsOpen(false);
  };

  const defaultTrigger = (
    <Button variant="outline" size="sm">
      <Settings className="w-4 h-4 mr-2" />
      Emergency Settings
    </Button>
  );

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {trigger || defaultTrigger}
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-brand-blue" />
            Emergency Response Settings
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Auto-trigger Enable/Disable */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <Card className="border-blue-200 bg-blue-50">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-blue-600" />
                  Auto-Emergency Detection
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label htmlFor="auto-trigger">Enable Automatic Emergency Detection</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically trigger emergency mode when you don't respond for a while
                    </p>
                  </div>
                  <Switch
                    id="auto-trigger"
                    checked={localSettings.autoTriggerEnabled}
                    onCheckedChange={(checked) => handleSettingChange('autoTriggerEnabled', checked)}
                  />
                </div>
                
                {localSettings.autoTriggerEnabled && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="pl-4 border-l-2 border-blue-200 space-y-4"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="response-timeout">Response Timeout (minutes)</Label>
                        <Select
                          value={localSettings.responseTimeoutMinutes.toString()}
                          onValueChange={(value) => handleSettingChange('responseTimeoutMinutes', parseInt(value))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="15">15 minutes</SelectItem>
                            <SelectItem value="30">30 minutes</SelectItem>
                            <SelectItem value="45">45 minutes</SelectItem>
                            <SelectItem value="60">1 hour</SelectItem>
                            <SelectItem value="120">2 hours</SelectItem>
                          </SelectContent>
                        </Select>
                        <p className="text-xs text-muted-foreground">
                          How long to wait before marking as non-responsive
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="check-interval">Check Interval (minutes)</Label>
                        <Select
                          value={localSettings.checkIntervalMinutes.toString()}
                          onValueChange={(value) => handleSettingChange('checkIntervalMinutes', parseInt(value))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="5">5 minutes</SelectItem>
                            <SelectItem value="10">10 minutes</SelectItem>
                            <SelectItem value="15">15 minutes</SelectItem>
                            <SelectItem value="30">30 minutes</SelectItem>
                          </SelectContent>
                        </Select>
                        <p className="text-xs text-muted-foreground">
                          How often to check for responses
                        </p>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="max-checks">Maximum Non-Responsive Checks</Label>
                      <Select
                        value={localSettings.maxNonResponsiveChecks.toString()}
                        onValueChange={(value) => handleSettingChange('maxNonResponsiveChecks', parseInt(value))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 check (Immediate)</SelectItem>
                          <SelectItem value="2">2 checks (Recommended)</SelectItem>
                          <SelectItem value="3">3 checks (Patient)</SelectItem>
                          <SelectItem value="5">5 checks (Very Patient)</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground">
                        How many failed checks before triggering emergency mode
                      </p>
                    </div>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Emergency Contact */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="space-y-4"
          >
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Phone className="w-5 h-5 text-green-600" />
                  Emergency Contact
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="emergency-contact">Contact Information</Label>
                  <Input
                    id="emergency-contact"
                    type="text"
                    placeholder="Name and phone number (e.g., 'Mom - (555) 123-4567')"
                    value={localSettings.emergencyContact || ''}
                    onChange={(e) => handleSettingChange('emergencyContact', e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    This contact will be shown in emergency situations. We will never call them without your permission.
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Current Status */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-4"
          >
            <Card className="border-green-200 bg-green-50">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Clock className="w-5 h-5 text-green-600" />
                  Current Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Monitoring:</span>
                    <span className={`ml-2 ${emergencyState.isMonitoring ? 'text-green-600' : 'text-yellow-600'}`}>
                      {emergencyState.isMonitoring ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  <div>
                    <span className="font-medium">Emergency Mode:</span>
                    <span className={`ml-2 ${emergencyState.isEmergencyMode ? 'text-red-600' : 'text-green-600'}`}>
                      {emergencyState.isEmergencyMode ? 'Active' : 'Normal'}
                    </span>
                  </div>
                  <div>
                    <span className="font-medium">Non-Responsive Count:</span>
                    <span className="ml-2">{emergencyState.nonResponsiveCount}</span>
                  </div>
                  <div>
                    <span className="font-medium">Pending Messages:</span>
                    <span className="ml-2">{emergencyState.pendingMessages}</span>
                  </div>
                </div>
                
                {emergencyState.lastUserActivity && (
                  <div className="text-sm">
                    <span className="font-medium">Last Activity:</span>
                    <span className="ml-2">
                      {new Date(emergencyState.lastUserActivity).toLocaleString()}
                    </span>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Example Timeline */}
          {localSettings.autoTriggerEnabled && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="space-y-4"
            >
              <Card className="border-amber-200 bg-amber-50">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Example Timeline</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <p><strong>Time 0:</strong> Saathi sends you a message</p>
                    <p><strong>Time +{localSettings.responseTimeoutMinutes}min:</strong> First non-responsive check</p>
                    <p><strong>Time +{localSettings.responseTimeoutMinutes + localSettings.checkIntervalMinutes}min:</strong> Second non-responsive check</p>
                    {localSettings.maxNonResponsiveChecks > 2 && (
                      <p><strong>Time +{localSettings.responseTimeoutMinutes + (localSettings.checkIntervalMinutes * 2)}min:</strong> Additional checks...</p>
                    )}
                    <p className="text-amber-700 font-medium">
                      <strong>Emergency triggered after {localSettings.maxNonResponsiveChecks} failed checks</strong>
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="flex justify-end gap-3 pt-4 border-t"
          >
            <Button variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
            <Button onClick={handleSave} className="gradient-saathi text-white">
              <Save className="w-4 h-4 mr-2" />
              Save Settings
            </Button>
          </motion.div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
