import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { AlertTriangle, Phone, X, Shield, Heart } from "lucide-react";

interface EmergencyButtonProps {
  isEmergencyMode?: boolean;
  onEmergencyClick?: () => void;
  onDismiss?: () => void;
}

export default function EmergencyButton({ 
  isEmergencyMode = false, 
  onEmergencyClick,
  onDismiss 
}: EmergencyButtonProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [isPulsing, setIsPulsing] = useState(false);

  // Start pulsing animation when in emergency mode
  useEffect(() => {
    if (isEmergencyMode) {
      setIsPulsing(true);
      const interval = setInterval(() => {
        setIsPulsing(prev => !prev);
      }, 1000);
      return () => clearInterval(interval);
    } else {
      setIsPulsing(false);
    }
  }, [isEmergencyMode]);

  const handleClick = () => {
    if (onEmergencyClick) {
      onEmergencyClick();
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0, opacity: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 20 }}
      >
        {/* Emergency Mode Banner */}
        <AnimatePresence>
          {isEmergencyMode && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.9 }}
              className="absolute bottom-20 right-0 bg-red-500 text-white px-4 py-2 rounded-lg shadow-lg mb-2 min-w-64"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <motion.div
                    animate={{ rotate: [0, 10, -10, 0] }}
                    transition={{ duration: 0.5, repeat: Infinity }}
                  >
                    <AlertTriangle className="w-4 h-4" />
                  </motion.div>
                  <span className="text-sm font-medium">Emergency Mode Active</span>
                </div>
                {onDismiss && (
                  <button 
                    onClick={onDismiss}
                    className="hover:bg-red-400 p-1 rounded"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
              <p className="text-xs mt-1 opacity-90">
                We noticed you haven't responded. Help is available.
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Emergency Button */}
        <motion.div
          className="relative"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onHoverStart={() => setIsHovered(true)}
          onHoverEnd={() => setIsHovered(false)}
        >
          {/* Pulse Ring Animation */}
          <motion.div
            className={`absolute inset-0 rounded-full ${
              isEmergencyMode ? 'bg-red-500' : 'bg-brand-blue'
            }`}
            animate={{
              scale: isPulsing ? [1, 1.4, 1] : 1,
              opacity: isPulsing ? [0.7, 0, 0.7] : 0
            }}
            transition={{
              duration: 1.5,
              repeat: isPulsing ? Infinity : 0,
              ease: "easeInOut"
            }}
          />

          {/* Outer Glow Ring */}
          <motion.div
            className={`absolute inset-0 rounded-full ${
              isEmergencyMode ? 'bg-red-400' : 'bg-brand-teal'
            }`}
            animate={{
              scale: isEmergencyMode ? [1, 1.2, 1] : 1,
              opacity: isEmergencyMode ? [0.3, 0.1, 0.3] : 0.2
            }}
            transition={{
              duration: 2,
              repeat: isEmergencyMode ? Infinity : 0,
              ease: "easeInOut"
            }}
          />

          {/* Main Button */}
          <Button
            onClick={handleClick}
            className={`
              relative w-16 h-16 rounded-full shadow-lg border-0 
              ${isEmergencyMode 
                ? 'bg-red-500 hover:bg-red-600 text-white' 
                : 'gradient-saathi text-white hover:shadow-xl'
              }
              transition-all duration-300
            `}
            size="lg"
          >
            <motion.div
              animate={{
                rotate: isEmergencyMode ? [0, 5, -5, 0] : 0,
                scale: isHovered ? 1.1 : 1
              }}
              transition={{
                duration: isEmergencyMode ? 0.5 : 0.2,
                repeat: isEmergencyMode ? Infinity : 0
              }}
            >
              {isEmergencyMode ? (
                <Phone className="w-7 h-7" />
              ) : (
                <Shield className="w-7 h-7" />
              )}
            </motion.div>
          </Button>

          {/* Tooltip */}
          <AnimatePresence>
            {isHovered && !isEmergencyMode && (
              <motion.div
                initial={{ opacity: 0, x: 10, scale: 0.9 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, x: 10, scale: 0.9 }}
                className="absolute right-20 top-1/2 transform -translate-y-1/2 bg-gray-900 text-white px-3 py-2 rounded-lg text-sm whitespace-nowrap shadow-lg"
              >
                Emergency Support
                <div className="absolute left-full top-1/2 transform -translate-y-1/2 border-4 border-transparent border-l-gray-900"></div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Floating Heart Animation for Normal Mode */}
        <AnimatePresence>
          {!isEmergencyMode && (
            <motion.div
              className="absolute -top-2 -right-2"
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0 }}
            >
              <motion.div
                animate={{ 
                  y: [0, -8, 0],
                  scale: [1, 1.1, 1]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className="w-6 h-6 bg-white rounded-full flex items-center justify-center shadow-md"
              >
                <Heart className="w-3 h-3 text-red-400 fill-current" />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Emergency Mode Indicator Dots */}
        <AnimatePresence>
          {isEmergencyMode && (
            <div className="absolute -top-1 -left-1 flex space-x-1">
              {[0, 1, 2].map((index) => (
                <motion.div
                  key={index}
                  className="w-2 h-2 bg-red-400 rounded-full"
                  animate={{
                    scale: [1, 1.2, 1],
                    opacity: [1, 0.5, 1]
                  }}
                  transition={{
                    duration: 0.8,
                    repeat: Infinity,
                    delay: index * 0.2
                  }}
                />
              ))}
            </div>
          )}
        </AnimatePresence>
      </motion.div>
    </AnimatePresence>
  );
}
